# -*- coding: utf-8 -*-

##
#   ADesk - plugin.conf.__init__
##
